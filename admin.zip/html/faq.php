<?php
require('../include/top.inc.php');

// Ensure the user is an admin
isAdmin();

// Initialize variables
$services = '';
$faq_heading_1 = '';
$faq_heading_2 = '';
$faq_heading_3 = '';
$faq_content_1 = '';
$faq_content_2 = '';
$faq_content_3 = '';
$msg = '';
$image_required = 'required';

// Check if an ID is provided and fetch the corresponding FAQ data
if (isset($_GET['id']) && $_GET['id'] !== '') {
    $id = get_safe_value($con, $_GET['id']);
    $res = mysqli_query($con, "SELECT * FROM faq WHERE id='$id'");
    $check = mysqli_num_rows($res);
    if ($check > 0) {
        $row = mysqli_fetch_assoc($res);
        $services = $row['services'];
        $faq_heading_1 = $row['faq_heading_1'];
        $faq_heading_2 = $row['faq_heading_2'];
        $faq_heading_3 = $row['faq_heading_3'];
        $faq_content_1 = $row['faq_content_1'];
        $faq_content_2 = $row['faq_content_2'];
        $faq_content_3 = $row['faq_content_3'];
    } else {
        header('Location: manage_faq.php');
        die();
    }
}

// Handle form submission
if (isset($_POST['submit'])) {
    // Get safe values from the form inputs
    $services = get_safe_value($con, $_POST['services']);
    $faq_heading_1 = get_safe_value($con, $_POST['faq_heading_1']);
    $faq_heading_2 = get_safe_value($con, $_POST['faq_heading_2']);
    $faq_heading_3 = get_safe_value($con, $_POST['faq_heading_3']);
    $faq_content_1 = get_safe_value($con, $_POST['faq_content_1']);
    $faq_content_2 = get_safe_value($con, $_POST['faq_content_2']);
    $faq_content_3 = get_safe_value($con, $_POST['faq_content_3']);

    // If there are no errors, process the form submission
    if (empty($msg)) {
        if (isset($_GET['id']) && $_GET['id'] !== '') {
            // Update existing FAQ entry
            $update_query = "UPDATE `faq` SET `faq_heading_1`='$faq_heading_1',`faq_heading_2`='$faq_heading_2',`faq_heading_3`='$faq_heading_3',`faq_content_1`='$faq_content_1',`faq_content_2`='$faq_content_2',`faq_content_3`='$faq_content_3',`services`='$services' WHERE `id`='$id'";
            mysqli_query($con, $update_query);
        } else {
            // Insert new FAQ entry
            $insert_query = "INSERT INTO `faq` (`faq_heading_1`, `faq_heading_2`, `faq_heading_3`, `faq_content_1`, `faq_content_2`, `faq_content_3`, `services`) VALUES ('$faq_heading_1', '$faq_heading_2', '$faq_heading_3', '$faq_content_1', '$faq_content_2', '$faq_content_3', '$services')";
            mysqli_query($con, $insert_query);
            print_r($insert_query);
        }
        header('Location: manage_faq.php');
        die();
    }
}
?>

<!-- Include the head file -->
<?php include("../include/head.inc.php"); ?>

<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h4 class="page-title">FAQ'S</h4>
            <div class="ms-auto text-end">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="index">Home</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            FAQ'S
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid" style="height: calc(100vh - 120px);">
    <div class="row">
        <!-- FAQ Form -->
        <div class="col-md-8 m-auto bg-white">
            <div class="card">
                <div class="card-header">
                    <strong>FAQ'S</strong>
                    <small> Form</small>
                </div>
                <form method="post" enctype="multipart/form-data">
                    <div class="card-body card-block">
                        <!-- Services Dropdown -->
                        <div class="form-group">
                            <label for="Short_Description" class="form-control-label">Services</label>
                            <select name="services" class="form-control" required>
                                <option value="" selected>-Select-</option>
                                <?php
                                // Fetch services from the database
                                $servicesql = "SELECT `title` FROM `services`";
                                $serviceres = mysqli_query($con, $servicesql);
                                while ($row = mysqli_fetch_assoc($serviceres)) {
                                    $selected = ($row['title'] === $services) ? 'selected' : '';
                                    echo "<option value='{$row['title']}' $selected>{$row['title']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        
                        <!-- FAQ Heading and Content Inputs -->
                        <div class="form-group">
                            <label for="faq_heading_1" class="form-control-label">FAQ Heading 1</label>
                            <input type="text" name="faq_heading_1" placeholder="Question 1" class="form-control" required value="<?php echo $faq_heading_1; ?>">
                        </div>
                        <div class="form-group">
                            <label for="faq_content_1" class="form-control-label">FAQ Content 1</label>
                            <input type="text" name="faq_content_1" placeholder="Answer 1" class="form-control" required value="<?php echo $faq_content_1; ?>">
                        </div>
                        <div class="form-group">
                            <label for="faq_heading_2" class="form-control-label">FAQ Heading 2</label>
                            <input type="text" name="faq_heading_2" placeholder="Question 2" class="form-control" required value="<?php echo $faq_heading_2; ?>">
                        </div>
                        <div class="form-group">
                            <label for="faq_content_2" class="form-control-label">FAQ Content 2</label>
                            <input type="text" name="faq_content_2" placeholder="Answer 2" class="form-control" required value="<?php echo $faq_content_2; ?>">
                        </div>
                        <div class="form-group">
                            <label for="faq_heading_3" class="form-control-label">FAQ Heading 3</label>
                            <input type="text" name="faq_heading_3" placeholder="Question 3" class="form-control" required value="<?php echo $faq_heading_3; ?>">
                        </div>
                        <div class="form-group">
                            <label for="faq_content_3" class="form-control-label">FAQ Content 3</label>
                            <input type="text" name="faq_content_3" placeholder="Answer 3" class="form-control" required value="<?php echo $faq_content_3; ?>">
                        </div>
                        
                        <!-- Submit Button -->
                        <button id="payment-button" name="submit" type="submit" class="btn btn-lg btn-info btn-block">
                            <span id="payment-button-amount">Submit</span>
                        </button>
                        <div class="field_error"><?php echo $msg; ?></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript Includes -->
<script src="../assets/libs/jquery/dist/jquery.min.js"></script>
<script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
<script src="../assets/extra-libs/sparkline/sparkline.js"></script>
<script src="../dist/js/waves.js"></script>
<script src="../dist/js/sidebarmenu.js"></script>
<script src="../dist/js/custom.min.js"></script>
<script src="../assets/extra-libs/multicheck/datatable-checkbox-init.js"></script>
<script src="../assets/extra-libs/multicheck/jquery.multicheck.js"></script>
<script src="../assets/extra-libs/DataTables/datatables.min.js"></script>
<script>
    $("#zero_config").DataTable();
</script>

<!-- CKEditor and CKFinder -->
<script src="../ckeditor/ckeditor.js"></script>
<script src="../ckfinder/ckfinder.js"></script>
<script>
    var editor = CKEDITOR.replace('editor1');
    CKFinder.setupCKEditor(editor);
</script>
</body>

</html>
